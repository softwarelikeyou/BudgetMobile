﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using TopUp.TopUp;

namespace TopUp
{
    class Program
    {
        static void Main(string[] args)
        {
            TopupService service = new TopupService();
            service.Url = "http://localhost/MVNO/Topup.wsdl";  //http://mvno-api01.budgetprepay.com/MVNO/Topup.wsd

            //EnterOrderDetailsRequest(service);
            CancelOrder(service);
        }

        private static void EnterOrderDetailsRequest(TopupService service) 
        {
            /* Testing MDNs
             5702092381
             2678008330
             2673008031
             2157042624
             7755278768
             5013086773
             2253495937
             7027086786 
            */

            try
            {
                EnterOrderDetailsRequest request = new EnterOrderDetailsRequest();
                messageHeaderType messageHeader = new messageHeaderType();
                messageHeader.username = "epay";
                request.messageHeader = messageHeader;
                request.mdn = "5702092381";
                request.productId = productIdType.Item1000TEXT;

                EnterOrderDetailsResponse response = service.EnterOrderDetails(request);

                System.Console.Out.WriteLine("Status: " + response.returnMessage.returnText);
                System.Console.Out.WriteLine("Reference: " + response.referenceId);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        private static void CancelOrder(TopupService service)
        {
            try
            {
                CancelOrderRequest request = new CancelOrderRequest();
                messageHeaderType messageHeader = new messageHeaderType();
                messageHeader.username = "epay";
                request.messageHeader = messageHeader;
                request.reason = reasonType.CANCEL;
                request.reasonSpecified = true;
                request.referenceId = "1234567890";

                CancelOrderResponse response = service.CancelOrder(request);

                System.Console.Out.WriteLine("Status: " + response.returnMessage.returnText);
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
